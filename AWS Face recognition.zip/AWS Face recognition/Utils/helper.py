import json

def response(status_code, body):
    return {
        'statusCode': status_code,
        'body': json.dumps(body)
    }
